const rect = {
    perimeter: (x, y) => 2 * (x + y),
    area: (x, y) => x * y
};
